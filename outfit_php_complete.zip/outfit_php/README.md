# Outfit Helper - PHP Version
## Complete PHP + MySQL Implementation

All features from the original Node.js/MongoDB version, rebuilt entirely in PHP.

---

## 📋 Requirements
- PHP 7.4+ (with PDO, PDO_MySQL extensions)
- MySQL 5.7+ or MariaDB 10+
- Apache with `mod_rewrite` **OR** use PHP's built-in server

---

## 🚀 Quick Setup

### Step 1: Database Setup
```sql
-- Run this in your MySQL client or phpMyAdmin:
SOURCE /path/to/outfit_php/config/setup.sql
```

Or manually:
```bash
mysql -u root -p < config/setup.sql
```

### Step 2: Configure Database
Edit `config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_mysql_username');
define('DB_PASS', 'your_mysql_password');
define('DB_NAME', 'outfit_helper');
define('SITE_URL', 'http://localhost:8000');  // your site URL
```

### Step 3: Run the Server

**Option A: PHP Built-in Server (easiest)**
```bash
cd /path/to/outfit_php
php -S localhost:8000 router.php
```
Then open: http://localhost:8000

**Option B: Apache**
- Point your Apache VirtualHost to the `outfit_php/` directory
- Make sure `mod_rewrite` is enabled
- The `.htaccess` file handles routing automatically

---

## 📁 Project Structure
```
outfit_php/
├── router.php              # Main PHP router (entry point)
├── .htaccess               # Apache URL rewriting rules
├── config/
│   ├── database.php        # DB credentials & PDO connection
│   └── setup.sql           # SQL to create tables
├── includes/
│   └── helpers.php         # JWT, auth, response helpers
├── api/
│   ├── auth.php            # Auth API: register/login/profile/password
│   └── wardrobe.php        # Wardrobe API: CRUD + image upload
└── public/
    ├── index.php           # Landing page
    ├── login.php           # Login page
    ├── register.php        # Registration page
    ├── forgot-password.php # Forgot password page
    ├── reset-password.php  # Reset password page
    ├── dashboard.php       # Main dashboard (auth required)
    ├── uploads/            # User uploaded images (auto-created)
    ├── css/
    │   ├── style.css       # Global styles
    │   ├── auth.css        # Auth page styles
    │   └── dashboard.css   # Dashboard styles
    └── js/
        ├── api.js          # Frontend API client
        ├── auth.js         # Auth page logic
        └── dashboard.js    # Dashboard logic
```

---

## 🔑 All Features Included

| Feature | Status |
|---------|--------|
| User Registration (name, gender, email, mobile, loginId) | ✅ |
| User Login (loginId or email) | ✅ |
| JWT Authentication (7 day tokens) | ✅ |
| Forgot Password (email link) | ✅ |
| Reset Password (token validation) | ✅ |
| View/Edit Profile | ✅ |
| Change Password | ✅ |
| Delete Account | ✅ |
| Upload wardrobe items with photos | ✅ |
| 5 Categories: Shirts, T-Shirts, Pants, Shoes, Dresses | ✅ |
| Delete wardrobe items (removes image file) | ✅ |
| Smart outfit suggestions (male/female logic) | ✅ |
| Color-based matching algorithm | ✅ |
| 4 Occasions: Casual, Formal, Party, Sports | ✅ |
| Track outfits created counter | ✅ |
| Dashboard stats (total items, outfits ready) | ✅ |

---

## 🔒 Security Features
- Passwords hashed with bcrypt (password_hash)
- JWT tokens signed with HMAC-SHA256
- PDO prepared statements (SQL injection protection)
- File type validation for image uploads
- Password reset tokens hashed with SHA-256
- Tokens expire in 30 minutes

---

## 📧 Email (Forgot Password)
By default uses PHP's `mail()` function. For production, configure an SMTP library like PHPMailer:
```bash
composer require phpmailer/phpmailer
```
Then update the email sending code in `api/auth.php` → `handleForgotPassword()`.
