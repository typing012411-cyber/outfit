<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Outfit Helper</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <a href="/index.php" class="back-link">← Back to Home</a>
                <h1>Create Your Account</h1>
                <p>Start organizing your wardrobe today!</p>
            </div>
            <div id="registerAlert" class="alert" style="display:none;"></div>
            <form id="registerForm" class="auth-form">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" required placeholder="John Doe">
                </div>
                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select id="gender" required>
                        <option value="">Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                        <option value="prefer-not-to-say">Prefer not to say</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" required placeholder="john@example.com">
                </div>
                <div class="form-group">
                    <label for="mobile">Mobile Number</label>
                    <input type="tel" id="mobile" required placeholder="+1 234 567 8900">
                </div>
                <div class="form-group">
                    <label for="loginId">Login ID</label>
                    <input type="text" id="loginId" required placeholder="johndoe123" minlength="4">
                    <small>At least 4 characters</small>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="password" required placeholder="Create a password" minlength="6">
                        <span class="password-toggle" onclick="togglePassword('password')">👁️</span>
                    </div>
                    <small>At least 6 characters</small>
                </div>
                <div class="form-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="confirmPassword" required placeholder="Re-enter password">
                        <span class="password-toggle" onclick="togglePassword('confirmPassword')">👁️</span>
                    </div>
                </div>
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" id="agreeTerms" required>
                        <span>I agree to the Terms of Service and Privacy Policy</span>
                    </label>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Create Account</button>
            </form>
            <div class="auth-footer">
                <p>Already have an account? <a href="/login.php" class="link">Login</a></p>
            </div>
        </div>
    </div>
    <script src="/js/api.js"></script>
    <script src="/js/auth.js"></script>
</body>
</html>
