<?php // Outfit Helper - Home Page ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Outfit Helper - Your personal stylist for managing your wardrobe and getting smart outfit suggestions">
    <title>Outfit Helper - Your Personal Stylist</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <span class="logo-icon">👔</span>
                <span class="logo-text">Outfit Helper</span>
            </div>
            <div class="nav-links">
                <a href="#home">Home</a>
                <a href="#features">Features</a>
                <a href="#how-it-works">How It Works</a>
                <a href="#about">About</a>
                <a href="/login.php" class="btn-nav">Login</a>
                <a href="/register.php" class="btn-nav-primary">Sign Up Free</a>
            </div>
            <div class="hamburger" onclick="toggleMobileMenu()">
                <span></span><span></span><span></span>
            </div>
        </div>
    </nav>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Your Personal Stylist</h1>
            <p class="hero-subtitle">Organize your wardrobe, get smart outfit suggestions, and never wonder "what to wear" again!</p>
            <div class="hero-buttons">
                <a href="/register.php" class="btn btn-primary btn-large">Get Started Free</a>
                <a href="#how-it-works" class="btn btn-secondary btn-large">See How It Works</a>
            </div>
        </div>
        <div class="hero-image">
            <div class="phone-mockup">
                <div class="phone-screen">
                    <img src="https://via.placeholder.com/300x600/9333EA/ffffff?text=Outfit+Helper" alt="Outfit Helper App">
                </div>
            </div>
        </div>
    </section>

    <section id="features" class="features">
        <div class="container">
            <h2 class="section-title">Powerful Features for Your Style</h2>
            <p class="section-subtitle">Everything you need to manage your wardrobe and look your best every day</p>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">📸</div>
                    <h3>Photo Upload</h3>
                    <p>Upload photos of your clothes from your phone or camera. Build your complete digital wardrobe.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🎨</div>
                    <h3>Smart Color Matching</h3>
                    <p>Advanced color analysis suggests perfectly matching outfits based on color theory.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">👔</div>
                    <h3>Organize by Category</h3>
                    <p>Sort your wardrobe into shirts, pants, shoes, dresses, and more for easy access.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">✨</div>
                    <h3>Occasion-Based Suggestions</h3>
                    <p>Get outfit recommendations for casual, formal, party, or sports occasions.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🛍️</div>
                    <h3>Shopping Recommendations</h3>
                    <p>Need more options? Get personalized shopping suggestions from top retailers.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">💾</div>
                    <h3>Save Your Favorites</h3>
                    <p>All your data is saved automatically. Access your wardrobe anytime, anywhere.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <h2 class="section-title">How It Works</h2>
            <p class="section-subtitle">Get started in 3 simple steps</p>
            <div class="steps">
                <div class="step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Create Your Account</h3>
                        <p>Sign up for free in less than 30 seconds. No credit card required.</p>
                    </div>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Upload Your Clothes</h3>
                        <p>Take photos of your wardrobe items and organize them by category. Add colors and names.</p>
                    </div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3>Get Outfit Suggestions</h3>
                        <p>Choose an occasion and let our AI create perfect outfit combinations for you!</p>
                    </div>
                </div>
            </div>
            <div class="cta-section">
                <a href="/register.php" class="btn btn-primary btn-large">Start Organizing Now</a>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>About Outfit Helper</h2>
                    <p>We created Outfit Helper to solve a problem we all face: managing our wardrobe and deciding what to wear. Our mission is to help people look their best every day with the help of smart technology.</p>
                    <p>Using advanced color matching algorithms and intelligent suggestions, we make fashion simple and fun. Whether you're getting ready for work, a date, or a workout, we've got you covered.</p>
                    <div class="about-stats">
                        <div class="about-stat"><h4>100%</h4><p>Free to Use</p></div>
                        <div class="about-stat"><h4>24/7</h4><p>Access Anytime</p></div>
                        <div class="about-stat"><h4>🔒</h4><p>Secure & Private</p></div>
                    </div>
                </div>
                <div class="about-image">
                    <img src="https://via.placeholder.com/500x400/9333EA/ffffff?text=Fashion+Technology" alt="About Outfit Helper">
                </div>
            </div>
        </div>
    </section>

    <section class="cta-banner">
        <div class="container">
            <h2>Ready to Transform Your Wardrobe?</h2>
            <p>Join thousands of users who are styling smarter, not harder</p>
            <a href="/register.php" class="btn btn-white btn-large">Get Started Free</a>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Outfit Helper</h3>
                    <p>Your personal stylist for smart wardrobe management.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook">📘</a>
                        <a href="#" aria-label="Twitter">🐦</a>
                        <a href="#" aria-label="Instagram">📷</a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#features">Features</a></li>
                        <li><a href="#how-it-works">How It Works</a></li>
                        <li><a href="#about">About Us</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Account</h4>
                    <ul>
                        <li><a href="/login.php">Login</a></li>
                        <li><a href="/register.php">Sign Up</a></li>
                        <li><a href="/forgot-password.php">Forgot Password</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Outfit Helper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
    function toggleMobileMenu() {
        const nav = document.querySelector('.nav-links');
        nav.classList.toggle('mobile-open');
    }
    </script>
</body>
</html>
