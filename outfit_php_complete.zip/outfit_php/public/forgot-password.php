<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Outfit Helper</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <a href="/login.php" class="back-link">← Back to Login</a>
                <h1>Forgot Password?</h1>
                <p>Enter your email or login ID and we'll send you a reset link.</p>
            </div>
            <div id="forgotAlert" class="alert" style="display:none;"></div>
            <form id="forgotForm" class="auth-form">
                <div class="form-group">
                    <label for="identifier">Email or Login ID</label>
                    <input type="text" id="identifier" required placeholder="Enter your email or login ID">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Send Reset Link</button>
            </form>
            <div class="auth-footer">
                <p>Remember your password? <a href="/login.php" class="link">Login</a></p>
            </div>
        </div>
    </div>
    <script src="/js/api.js"></script>
    <script src="/js/auth.js"></script>
</body>
</html>
