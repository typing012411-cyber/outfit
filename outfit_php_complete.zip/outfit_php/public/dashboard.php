<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Outfit Helper</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/dashboard.css">
</head>
<body>
    <nav class="dashboard-nav">
        <div class="nav-container">
            <div class="logo">
                <span class="logo-icon">👔</span>
                <span class="logo-text">Outfit Helper</span>
            </div>
            <div class="nav-user">
                <span class="welcome-text">Welcome, <strong id="userName"></strong>!</span>
                <button class="btn btn-secondary btn-small" onclick="logout()">Logout</button>
            </div>
        </div>
    </nav>

    <div class="dashboard-container">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="#" class="active" onclick="showSection('overview')">📊 Overview</a></li>
                <li><a href="#" onclick="showSection('profile')">👤 Profile</a></li>
                <li><a href="#" onclick="showSection('shirts')">👔 Shirts</a></li>
                <li><a href="#" onclick="showSection('tshirts')">👕 T-Shirts</a></li>
                <li><a href="#" onclick="showSection('pants')">👖 Pants</a></li>
                <li><a href="#" onclick="showSection('shoes')">👟 Shoes</a></li>
                <li><a href="#" onclick="showSection('dresses')">👗 Dresses</a></li>
                <li><a href="#" onclick="showSection('suggestions')">✨ Get Suggestions</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <!-- Overview -->
            <section id="overview" class="content-section active">
                <h2>Dashboard Overview</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">👔</div>
                        <div class="stat-info"><h3 id="totalItems">0</h3><p>Total Items</p></div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">✨</div>
                        <div class="stat-info"><h3 id="outfitsReady">0</h3><p>Outfits Ready</p></div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">📁</div>
                        <div class="stat-info"><h3>5</h3><p>Categories</p></div>
                    </div>
                </div>
                <div class="category-overview">
                    <h3>Your Wardrobe</h3>
                    <div class="category-grid">
                        <div class="category-card" onclick="showSection('shirts')">
                            <div class="category-icon">👔</div>
                            <h4>Shirts</h4>
                            <p><span id="shirtsCount">0</span> items</p>
                        </div>
                        <div class="category-card" onclick="showSection('tshirts')">
                            <div class="category-icon">👕</div>
                            <h4>T-Shirts</h4>
                            <p><span id="tshirtsCount">0</span> items</p>
                        </div>
                        <div class="category-card" onclick="showSection('pants')">
                            <div class="category-icon">👖</div>
                            <h4>Pants</h4>
                            <p><span id="pantsCount">0</span> items</p>
                        </div>
                        <div class="category-card" onclick="showSection('shoes')">
                            <div class="category-icon">👟</div>
                            <h4>Shoes</h4>
                            <p><span id="shoesCount">0</span> items</p>
                        </div>
                        <div class="category-card" onclick="showSection('dresses')">
                            <div class="category-icon">👗</div>
                            <h4>Dresses</h4>
                            <p><span id="dressesCount">0</span> items</p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Profile -->
            <section id="profile" class="content-section">
                <h2>My Profile</h2>
                <div class="profile-header">
                    <div class="profile-avatar" id="profileInitials">?</div>
                    <div class="profile-info">
                        <h3 id="profileDisplayName">User Name</h3>
                        <p id="profileDisplayEmail">user@example.com</p>
                    </div>
                </div>

                <div class="profile-info-card">
                    <div class="profile-card-header">
                        <h3>Personal Information</h3>
                        <button class="btn btn-secondary btn-small" onclick="toggleEditMode()" id="editBtn">✏️ Edit Profile</button>
                    </div>
                    <form id="profileForm" class="profile-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" id="profileName" disabled>
                            </div>
                            <div class="form-group">
                                <label>Gender</label>
                                <select id="profileGender" disabled>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                    <option value="prefer-not-to-say">Prefer not to say</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" id="profileEmail" disabled>
                            </div>
                            <div class="form-group">
                                <label>Mobile Number</label>
                                <input type="tel" id="profileMobile" disabled>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Login ID</label>
                                <input type="text" id="profileLoginId" disabled readonly style="background:#f5f5f5;">
                                <small>Login ID cannot be changed</small>
                            </div>
                        </div>
                        <div class="profile-actions" id="profileActions" style="display:none;">
                            <button type="button" class="btn btn-primary" onclick="saveProfile()">💾 Save Changes</button>
                            <button type="button" class="btn btn-secondary" onclick="cancelEdit()">✖️ Cancel</button>
                        </div>
                    </form>
                </div>

                <div class="profile-info-card">
                    <div class="profile-card-header"><h3>Security</h3></div>
                    <form id="passwordForm" class="profile-form" onsubmit="changePassword(event)">
                        <div class="form-group">
                            <label>Current Password</label>
                            <div class="password-wrapper">
                                <input type="password" id="currentPassword" placeholder="Enter current password">
                                <span class="password-toggle" onclick="togglePasswordField('currentPassword')">👁️</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <div class="password-wrapper">
                                <input type="password" id="newPassword" placeholder="Enter new password" minlength="6">
                                <span class="password-toggle" onclick="togglePasswordField('newPassword')">👁️</span>
                            </div>
                            <small>At least 6 characters</small>
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <div class="password-wrapper">
                                <input type="password" id="confirmNewPassword" placeholder="Re-enter new password">
                                <span class="password-toggle" onclick="togglePasswordField('confirmNewPassword')">👁️</span>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">🔒 Change Password</button>
                    </form>
                </div>

                <div class="profile-info-card">
                    <div class="profile-card-header"><h3>Account Statistics</h3></div>
                    <div class="account-stats">
                        <div class="stat-item">
                            <span class="stat-icon">👔</span>
                            <div><h4 id="profileTotalItems">0</h4><p>Total Items</p></div>
                        </div>
                        <div class="stat-item">
                            <span class="stat-icon">✨</span>
                            <div><h4 id="profileOutfitsCreated">0</h4><p>Outfits Created</p></div>
                        </div>
                        <div class="stat-item">
                            <span class="stat-icon">📅</span>
                            <div><h4 id="memberSince"><?php echo date('Y'); ?></h4><p>Member Since</p></div>
                        </div>
                    </div>
                </div>

                <div class="profile-info-card danger-zone">
                    <div class="profile-card-header"><h3>⚠️ Danger Zone</h3></div>
                    <p style="color:#666;margin-bottom:15px;">Once you delete your account, there is no going back. Please be certain.</p>
                    <button type="button" class="btn btn-danger" onclick="deleteAccount()">🗑️ Delete Account</button>
                </div>
            </section>

            <!-- Category Sections (rendered dynamically by JS) -->
            <section id="shirts" class="content-section category-section"></section>
            <section id="tshirts" class="content-section category-section"></section>
            <section id="pants" class="content-section category-section"></section>
            <section id="shoes" class="content-section category-section"></section>
            <section id="dresses" class="content-section category-section"></section>

            <!-- Suggestions -->
            <section id="suggestions" class="content-section">
                <h2>Get Outfit Suggestions</h2>
                <div class="occasion-selector">
                    <h3>Select Occasion</h3>
                    <div class="occasion-grid">
                        <label class="occasion-option">
                            <input type="radio" name="occasion" value="casual" checked>
                            <div class="occasion-card"><span class="occasion-icon">👕</span><span>Casual</span></div>
                        </label>
                        <label class="occasion-option">
                            <input type="radio" name="occasion" value="formal">
                            <div class="occasion-card"><span class="occasion-icon">👔</span><span>Formal</span></div>
                        </label>
                        <label class="occasion-option">
                            <input type="radio" name="occasion" value="party">
                            <div class="occasion-card"><span class="occasion-icon">🎉</span><span>Party</span></div>
                        </label>
                        <label class="occasion-option">
                            <input type="radio" name="occasion" value="sports">
                            <div class="occasion-card"><span class="occasion-icon">⚽</span><span>Sports</span></div>
                        </label>
                    </div>
                    <button class="btn btn-primary btn-large" onclick="generateOutfits()">Generate Outfits ✨</button>
                </div>
                <div id="outfitResults" class="outfit-results"></div>
            </section>
        </main>
    </div>

    <script src="/js/api.js"></script>
    <script src="/js/dashboard.js"></script>
</body>
</html>
