<?php
$token = htmlspecialchars($_GET['token'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Outfit Helper</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <a href="/login.php" class="back-link">← Back to Login</a>
                <h1>Reset Password</h1>
                <p>Enter your new password below.</p>
            </div>
            <?php if (!$token): ?>
            <div class="alert alert-error" style="display:block;">
                Invalid or missing reset link. Please <a href="/forgot-password.php">request a new one</a>.
            </div>
            <?php else: ?>
            <div id="resetAlert" class="alert" style="display:none;"></div>
            <form id="resetForm" class="auth-form">
                <input type="hidden" id="resetToken" value="<?= $token ?>">
                <div class="form-group">
                    <label for="newPassword">New Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="newPassword" required placeholder="Enter new password" minlength="6">
                        <span class="password-toggle" onclick="togglePassword('newPassword')">👁️</span>
                    </div>
                    <small>At least 6 characters</small>
                </div>
                <div class="form-group">
                    <label for="confirmNewPassword">Confirm New Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="confirmNewPassword" required placeholder="Re-enter new password">
                        <span class="password-toggle" onclick="togglePassword('confirmNewPassword')">👁️</span>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
            </form>
            <?php endif; ?>
            <div class="auth-footer">
                <p>Remember your password? <a href="/login.php" class="link">Login</a></p>
            </div>
        </div>
    </div>
    <script src="/js/api.js"></script>
    <script src="/js/auth.js"></script>
    <script>
    // Override token retrieval to use hidden field instead of URL param
    document.addEventListener('DOMContentLoaded', function() {
        const resetForm = document.getElementById('resetForm');
        if (resetForm) {
            resetForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                const token = document.getElementById('resetToken').value;
                const newPassword = document.getElementById('newPassword').value;
                const confirm = document.getElementById('confirmNewPassword').value;
                if (newPassword !== confirm) { showAlert('resetAlert', 'Passwords do not match!', 'error'); return; }
                const btn = resetForm.querySelector('button[type=submit]');
                btn.textContent = 'Resetting...'; btn.disabled = true;
                try {
                    await AuthAPI.resetPassword(token, newPassword);
                    showAlert('resetAlert', 'Password reset successful! Redirecting to login...', 'success');
                    setTimeout(() => window.location.href = '/login.php', 2000);
                } catch(err) {
                    showAlert('resetAlert', err.message, 'error');
                    btn.textContent = 'Reset Password'; btn.disabled = false;
                }
            }, true); // true = capture, overrides auth.js listener
        }
    });
    </script>
</body>
</html>
