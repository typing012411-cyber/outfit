// auth.js - handles login, register, forgot & reset password pages
document.addEventListener('DOMContentLoaded', () => {
    const page = window.location.pathname.split('/').pop() || 'index.php';

    // Redirect logged-in users away from auth pages
    if (['login.php', 'register.php'].includes(page)) {
        redirectIfLoggedIn();
    }

    // ── Register ──────────────────────────────────────────
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = registerForm.querySelector('button[type=submit]');
            btn.textContent = 'Creating Account...';
            btn.disabled = true;

            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (password !== confirmPassword) {
                showAlert('registerAlert', 'Passwords do not match!', 'error');
                btn.textContent = 'Create Account';
                btn.disabled = false;
                return;
            }

            try {
                await AuthAPI.register({
                    name: document.getElementById('name').value,
                    gender: document.getElementById('gender').value,
                    email: document.getElementById('email').value,
                    mobile: document.getElementById('mobile').value,
                    loginId: document.getElementById('loginId').value,
                    password
                });
                showAlert('registerAlert', 'Registration successful! Redirecting to login...', 'success');
                setTimeout(() => window.location.href = '/login.php', 2000);
            } catch (err) {
                showAlert('registerAlert', err.message, 'error');
                btn.textContent = 'Create Account';
                btn.disabled = false;
            }
        });
    }

    // ── Login ─────────────────────────────────────────────
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = loginForm.querySelector('button[type=submit]');
            btn.textContent = 'Logging in...';
            btn.disabled = true;

            try {
                await AuthAPI.login(
                    document.getElementById('loginId').value,
                    document.getElementById('password').value
                );
                window.location.href = '/dashboard.html';
            } catch (err) {
                showAlert('loginAlert', err.message, 'error');
                btn.textContent = 'Login';
                btn.disabled = false;
            }
        });
    }

    // ── Forgot Password ───────────────────────────────────
    const forgotForm = document.getElementById('forgotForm');
    if (forgotForm) {
        forgotForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = forgotForm.querySelector('button[type=submit]');
            btn.textContent = 'Sending...';
            btn.disabled = true;

            try {
                const data = await AuthAPI.forgotPassword(
                    document.getElementById('identifier').value
                );
                showAlert('forgotAlert', data.message, 'success');
                btn.textContent = 'Email Sent ✓';
            } catch (err) {
                showAlert('forgotAlert', err.message, 'error');
                btn.textContent = 'Send Reset Link';
                btn.disabled = false;
            }
        });
    }

    // ── Reset Password (from email link) ──────────────────
    const resetForm = document.getElementById('resetForm');
    if (resetForm) {
        const params = new URLSearchParams(window.location.search);
        const token = params.get('token');
        if (!token) {
            showAlert('resetAlert', 'Invalid or missing reset link. Please request a new one.', 'error');
        }

        resetForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const newPassword = document.getElementById('newPassword').value;
            const confirmPwd = document.getElementById('confirmNewPassword').value;

            if (newPassword !== confirmPwd) {
                showAlert('resetAlert', 'Passwords do not match!', 'error');
                return;
            }

            const btn = resetForm.querySelector('button[type=submit]');
            btn.textContent = 'Resetting...';
            btn.disabled = true;

            try {
                await AuthAPI.resetPassword(token, newPassword);
                showAlert('resetAlert', 'Password reset successful! Redirecting to login...', 'success');
                setTimeout(() => window.location.href = '/login.php', 2000);
            } catch (err) {
                showAlert('resetAlert', err.message, 'error');
                btn.textContent = 'Reset Password';
                btn.disabled = false;
            }
        });
    }
});

// Toggle password visibility
function togglePassword(id) {
    const el = document.getElementById(id);
    el.type = el.type === 'password' ? 'text' : 'password';
}
