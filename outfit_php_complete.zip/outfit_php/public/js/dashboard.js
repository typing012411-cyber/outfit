// dashboard.js — Cleaned & Optimized

let currentUser = null;
let wardrobe = { shirts: [], tshirts: [], pants: [], shoes: [], dresses: [] };
let currentCategory = '';

// ─── INIT ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    if (!requireAuth()) return;
    currentUser = getUser();
    document.getElementById('userName').textContent = currentUser.name;
    await loadWardrobe();
    updateStats();
});

// ─── LOAD WARDROBE FROM SERVER ───────────────────────────────
async function loadWardrobe() {
    try {
        const data = await WardrobeAPI.getWardrobe();
        wardrobe = {
            shirts:  data.shirts  || [],
            tshirts: data.tshirts || [],
            pants:   data.pants   || [],
            shoes:   data.shoes   || [],
            dresses: data.dresses || []
        };
        updateStats();
    } catch (err) {
        showNotification('Failed to load wardrobe: ' + err.message, 'error');
    }
}

// ─── UPDATE STATS ────────────────────────────────────────────
function updateStats() {
    const total = Object.values(wardrobe).reduce((s, a) => s + a.length, 0);
    document.getElementById('totalItems').textContent = total;

    const gender = (currentUser?.gender || 'other').toLowerCase();
    const tops = [...wardrobe.shirts, ...wardrobe.tshirts];

    let outfitsReady;
    if (gender === 'female') {
        outfitsReady = Math.max(
            Math.min(tops.length, wardrobe.shoes.length),
            Math.min(wardrobe.dresses.length, wardrobe.shoes.length)
        );
    } else {
        outfitsReady = Math.min(tops.length, wardrobe.pants.length, wardrobe.shoes.length);
    }

    document.getElementById('outfitsReady').textContent = outfitsReady;

    ['shirts','tshirts','pants','shoes','dresses'].forEach(cat => {
        const el = document.getElementById(`${cat}Count`);
        if (el) el.textContent = wardrobe[cat].length;
    });
}

// ─── SHOW SECTION ────────────────────────────────────────────
function showSection(sectionId) {
    document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
    document.getElementById(sectionId)?.classList.add('active');
    if (event?.target) event.target.classList.add('active');
    if (['shirts','tshirts','pants','shoes','dresses'].includes(sectionId)) {
        currentCategory = sectionId;
        renderCategorySection(sectionId);
    }
    if (sectionId === 'profile') loadProfileData();
}

// ─── RENDER CATEGORY ─────────────────────────────────────────
function renderCategorySection(category) {
    const section = document.getElementById(category);
    const meta = {
        shirts:  { name: 'Shirts',   icon: '👔' },
        tshirts: { name: 'T-Shirts', icon: '👕' },
        pants:   { name: 'Pants',    icon: '👖' },
        shoes:   { name: 'Shoes',    icon: '👟' },
        dresses: { name: 'Dresses',  icon: '👗' }
    };
    const { name, icon } = meta[category];
    const items = wardrobe[category];

    section.innerHTML = `
        <div class="category-header">
            <h2>${icon} ${name}</h2>
        </div>
        <div class="upload-section" onclick="document.getElementById('fileInput-${category}').click()">
            <div class="upload-icon">📸</div>
            <h3>Upload ${name}</h3>
            <p>Click to add photos to your wardrobe</p>
            <input type="file" id="fileInput-${category}" accept="image/*" style="display:none;"
                   onchange="handleImageUpload('${category}', event)">
        </div>
        <div class="items-grid" id="items-${category}">
            ${items.length === 0
                ? `<div class="empty-state">
                       <div class="icon">${icon}</div>
                       <p>No items yet!</p>
                       <p>Upload your first ${name.toLowerCase()} to get started.</p>
                   </div>`
                : items.map(item => `
                    <div class="item-card">
                        <img src="${item.imageUrl}" alt="${item.name}">
                        <button class="item-delete" onclick="deleteItem('${category}','${item._id}')">×</button>
                        <div class="item-card-content">
                            <h4>${item.name}</h4>
                            <p>Color: ${item.color}</p>
                        </div>
                    </div>`).join('')}
        </div>`;
}

// ─── UPLOAD IMAGE ────────────────────────────────────────────
async function handleImageUpload(category, event) {
    const file = event.target.files[0];
    if (!file) return;
    const itemName = prompt(`Enter name for this item:`, `My ${category.slice(0,-1)}`);
    if (!itemName) return;
    const itemColor = prompt('Enter the primary color (e.g. Blue, Black):');
    if (!itemColor) return;
    showNotification('Uploading...', 'info');
    try {
        const data = await WardrobeAPI.addItem(category, itemName, itemColor, file);
        wardrobe[category] = data.wardrobe[category];
        updateStats();
        renderCategorySection(category);
        showNotification('Item added successfully!', 'success');
    } catch (err) {
        showNotification('Upload failed: ' + err.message, 'error');
    }
    event.target.value = '';
}

// ─── DELETE ITEM ─────────────────────────────────────────────
async function deleteItem(category, itemId) {
    if (!confirm('Delete this item?')) return;
    try {
        const data = await WardrobeAPI.deleteItem(category, itemId);
        wardrobe[category] = data.wardrobe[category];
        updateStats();
        renderCategorySection(category);
        showNotification('Item deleted!', 'success');
    } catch (err) {
        showNotification('Delete failed: ' + err.message, 'error');
    }
}

// ─── COLOR MATCHING ──────────────────────────────────────────
const colorPairs = {
    black:  ['white','gray','grey','blue','red','pink','beige','cream','yellow','purple'],
    white:  ['black','blue','navy','gray','grey','brown','green','red','pink'],
    blue:   ['white','beige','gray','grey','black','brown','khaki'],
    navy:   ['white','beige','gray','grey','pink','red','khaki'],
    gray:   ['white','black','pink','blue','yellow','purple','navy'],
    grey:   ['white','black','pink','blue','yellow','purple','navy'],
    brown:  ['white','beige','cream','blue','khaki','green'],
    beige:  ['navy','brown','white','black','blue','green'],
    cream:  ['brown','navy','black','blue'],
    khaki:  ['white','navy','brown','blue','green'],
    red:    ['black','white','gray','grey','navy'],
    green:  ['white','beige','brown','black','khaki','blue'],
    pink:   ['gray','grey','navy','white','black'],
    purple: ['white','gray','grey','black','beige'],
    yellow: ['gray','grey','navy','white','black','blue'],
    orange: ['navy','brown','white','gray']
};

function colorsMatch(c1, c2) {
    const a = c1.toLowerCase().trim();
    const b = c2.toLowerCase().trim();
    if (a === b) return false;
    return colorPairs[a]?.includes(b) || colorPairs[b]?.includes(a) || false;
}

function shuffle(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

// ─── GENERATE OUTFITS ────────────────────────────────────────
function generateOutfits() {
    const gender = (currentUser?.gender || 'other').toLowerCase();
    const occasion = document.querySelector('input[name="occasion"]:checked').value;

    const occasionMeta = {
        casual: { preferTshirts: true,  preferColors: ['blue','white','gray','grey','green','khaki'],  label: 'Casual & Comfortable' },
        formal: { preferShirts: true,   preferColors: ['white','black','navy','blue','gray','beige'],  label: 'Professional & Formal' },
        party:  { preferShirts: true,   preferColors: ['black','red','purple','pink','blue','white'],  label: 'Party Ready & Stylish' },
        sports: { preferTshirts: true,  preferColors: ['black','blue','red','green','white','yellow'], label: 'Active & Sporty' }
    };

    const meta = occasionMeta[occasion];
    const suggestions = [];

    if (gender === 'female') {
        suggestions.push(...generateFemaleOutfits(meta, occasion));
    } else {
        suggestions.push(...generateMaleOutfits(meta, occasion));
    }

    if (!suggestions.length) {
        const hint = gender === 'female'
            ? 'Add at least one top or dress, and shoes!'
            : 'Add at least one top, pants, and shoes!';
        showNotification(hint, 'error');
        return;
    }

    displayOutfits(suggestions, occasion);
    WardrobeAPI.trackOutfit().catch(() => {});
    if (currentUser) {
        currentUser.outfitsCreated = (currentUser.outfitsCreated || 0) + suggestions.length;
        setUser(currentUser);
    }
    showNotification(`Generated ${suggestions.length} unique ${occasion} outfits!`, 'success');
}

// ─── FEMALE OUTFIT LOGIC ─────────────────────────────────────
function generateFemaleOutfits(meta, occasion) {
    const suggestions = [];
    const used = new Set();
    const shoes   = wardrobe.shoes;
    const tops    = [...wardrobe.shirts, ...wardrobe.tshirts];
    const pants   = wardrobe.pants;
    const dresses = wardrobe.dresses;
    const max     = 5;

    const colorScore = item => meta.preferColors.some(c => item.color.toLowerCase().includes(c)) ? 10 : 0;

    // Dresses + shoes (higher priority for formal/party)
    if (dresses.length && shoes.length) {
        const orderedDresses = shuffle(dresses).sort((a, b) => colorScore(b) - colorScore(a));
        const sShoes = shuffle(shoes);
        for (let i = 0; i < orderedDresses.length && suggestions.length < Math.ceil(max / 2); i++) {
            const dress = orderedDresses[i];
            const shoe  = sShoes[i % sShoes.length];
            const key = `dress-${dress._id}-${shoe._id}`;
            if (used.has(key)) continue;
            used.add(key);
            suggestions.push({
                id: suggestions.length + 1,
                dress, shoe, occasion,
                occasionStyle: meta.label,
                matchScore: colorsMatch(dress.color, shoe.color) ? 'Perfect Match! 🌟' : 'Good Combination ✨'
            });
        }
    }

    // Tops + pants + shoes
    if (tops.length && pants.length && shoes.length && suggestions.length < max) {
        const orderedTops = shuffle(tops).sort((a, b) => colorScore(b) - colorScore(a));
        const sPants = shuffle(pants);
        const sShoes = shuffle(shoes);
        let attempts = 0;
        while (suggestions.length < max && attempts < orderedTops.length * sPants.length) {
            const top  = orderedTops[attempts % orderedTops.length];
            const pant = sPants[Math.floor(attempts / orderedTops.length) % sPants.length];
            const shoe = sShoes[suggestions.length % sShoes.length];
            attempts++;
            const key = `top-${top._id}-${pant._id}-${shoe._id}`;
            if (used.has(key)) continue;
            used.add(key);
            suggestions.push({
                id: suggestions.length + 1,
                top, pant, shoe, occasion,
                occasionStyle: meta.label,
                matchScore: colorsMatch(top.color, pant.color) ? 'Perfect Match! 🌟' : 'Good Combination ✨'
            });
        }
    }

    return suggestions;
}

// ─── MALE / OTHER OUTFIT LOGIC ───────────────────────────────
function generateMaleOutfits(meta, occasion) {
    const tops  = [...wardrobe.shirts, ...wardrobe.tshirts];
    const pants = wardrobe.pants;
    const shoes = wardrobe.shoes;

    if (!tops.length || !pants.length || !shoes.length) return [];

    let orderedTops;
    if (meta.preferTshirts && wardrobe.tshirts.length) {
        orderedTops = [...shuffle(wardrobe.tshirts), ...shuffle(wardrobe.shirts)];
    } else if (meta.preferShirts && wardrobe.shirts.length) {
        orderedTops = [...shuffle(wardrobe.shirts), ...shuffle(wardrobe.tshirts)];
    } else {
        orderedTops = shuffle(tops);
    }

    const colorScore = item => meta.preferColors.some(c => item.color.toLowerCase().includes(c)) ? 10 : 0;
    orderedTops.sort((a, b) => colorScore(b) - colorScore(a));

    const sPants = occasion === 'casual' || occasion === 'sports'
        ? shuffle(pants)
        : [...pants].sort((a, b) => colorScore(b) - colorScore(a));

    const sShoes = shuffle(shoes);
    const suggestions = [];
    const used = new Set();
    const max = 5;
    let attempts = 0;

    while (suggestions.length < max && attempts < orderedTops.length * sPants.length) {
        const top  = orderedTops[attempts % orderedTops.length];
        const pant = sPants[Math.floor(attempts / orderedTops.length) % sPants.length];
        const shoe = sShoes[suggestions.length % sShoes.length];
        attempts++;
        const key = `${top._id}-${pant._id}-${shoe._id}`;
        if (used.has(key)) continue;
        used.add(key);
        suggestions.push({
            id: suggestions.length + 1,
            top, pant, shoe, occasion,
            occasionStyle: meta.label,
            matchScore: colorsMatch(top.color, pant.color) ? 'Perfect Match! 🌟' : 'Good Combination ✨'
        });
    }

    return suggestions;
}

// ─── DISPLAY OUTFITS ─────────────────────────────────────────
function displayOutfits(outfits, occasion) {
    const container = document.getElementById('outfitResults');

    container.innerHTML = outfits.map(outfit => {
        const isDressOnly = !!outfit.dress && !outfit.top;

        if (isDressOnly) {
            return `
            <div class="outfit-card">
                <div class="outfit-header">
                    <h3>Outfit ${outfit.id}</h3>
                    <div>
                        <span>${outfit.matchScore}</span>
                        <br><small style="opacity:.9">${outfit.occasionStyle}</small>
                    </div>
                </div>
                <div class="outfit-items">
                    <div class="outfit-item">
                        <img src="${outfit.dress.imageUrl}" alt="${outfit.dress.name}">
                        <h5>Dress</h5><p>${outfit.dress.name}</p>
                        <p style="color:var(--primary-color);font-weight:600">Color: ${outfit.dress.color}</p>
                    </div>
                    <div class="outfit-item">
                        <img src="${outfit.shoe.imageUrl}" alt="${outfit.shoe.name}">
                        <h5>Shoes</h5><p>${outfit.shoe.name}</p>
                        <p style="color:var(--primary-color);font-weight:600">Color: ${outfit.shoe.color}</p>
                    </div>
                </div>
            </div>`;
        }

        return `
        <div class="outfit-card">
            <div class="outfit-header">
                <h3>Outfit ${outfit.id}</h3>
                <div>
                    <span>${outfit.matchScore}</span>
                    ${outfit.occasionStyle ? `<br><small style="opacity:.9">${outfit.occasionStyle}</small>` : ''}
                </div>
            </div>
            <div class="outfit-items">
                <div class="outfit-item">
                    <img src="${outfit.top.imageUrl}" alt="${outfit.top.name}">
                    <h5>Top</h5><p>${outfit.top.name}</p>
                    <p style="color:var(--primary-color);font-weight:600">Color: ${outfit.top.color}</p>
                </div>
                <div class="outfit-item">
                    <img src="${outfit.pant.imageUrl}" alt="${outfit.pant.name}">
                    <h5>Bottom</h5><p>${outfit.pant.name}</p>
                    <p style="color:var(--primary-color);font-weight:600">Color: ${outfit.pant.color}</p>
                </div>
                <div class="outfit-item">
                    <img src="${outfit.shoe.imageUrl}" alt="${outfit.shoe.name}">
                    <h5>Shoes</h5><p>${outfit.shoe.name}</p>
                    <p style="color:var(--primary-color);font-weight:600">Color: ${outfit.shoe.color}</p>
                </div>
                ${outfit.dress ? `
                <div class="outfit-item">
                    <img src="${outfit.dress.imageUrl}" alt="${outfit.dress.name}">
                    <h5>Extra</h5><p>${outfit.dress.name}</p>
                    <p style="color:var(--primary-color);font-weight:600">Color: ${outfit.dress.color}</p>
                </div>` : ''}
            </div>
        </div>`;
    }).join('');

    container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ─── PROFILE ─────────────────────────────────────────────────
function loadProfileData() {
    if (!currentUser) return;
    const initials = currentUser.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
    document.getElementById('profileInitials').textContent = initials;
    document.getElementById('profileDisplayName').textContent = currentUser.name;
    document.getElementById('profileDisplayEmail').textContent = currentUser.email;
    document.getElementById('profileName').value    = currentUser.name;
    document.getElementById('profileGender').value  = currentUser.gender;
    document.getElementById('profileEmail').value   = currentUser.email;
    document.getElementById('profileMobile').value  = currentUser.mobile;
    document.getElementById('profileLoginId').value = currentUser.loginId;

    const total = Object.values(wardrobe).reduce((s, a) => s + a.length, 0);
    document.getElementById('profileTotalItems').textContent = total;
    document.getElementById('profileOutfitsCreated').textContent = currentUser.outfitsCreated || 0;
    document.getElementById('memberSince').textContent = new Date(currentUser.createdAt).getFullYear();
}

let isEditMode = false;
function toggleEditMode() {
    isEditMode = !isEditMode;
    ['profileName','profileGender','profileEmail','profileMobile'].forEach(id => {
        document.getElementById(id).disabled = !isEditMode;
    });
    document.getElementById('editBtn').textContent = isEditMode ? '✖️ Cancel Edit' : '✏️ Edit Profile';
    document.getElementById('profileActions').style.display = isEditMode ? 'flex' : 'none';
    if (!isEditMode) loadProfileData();
}

async function saveProfile() {
    try {
        const data = await AuthAPI.updateProfile({
            name:   document.getElementById('profileName').value,
            gender: document.getElementById('profileGender').value,
            email:  document.getElementById('profileEmail').value,
            mobile: document.getElementById('profileMobile').value
        });
        currentUser = { ...currentUser, ...data.user };
        setUser(currentUser);
        document.getElementById('userName').textContent = currentUser.name;
        toggleEditMode();
        showNotification('Profile updated!', 'success');
    } catch (err) {
        showNotification(err.message, 'error');
    }
}

function cancelEdit() { toggleEditMode(); }

function togglePasswordField(id) {
    const el = document.getElementById(id);
    el.type = el.type === 'password' ? 'text' : 'password';
}

async function changePassword(event) {
    event.preventDefault();
    const current = document.getElementById('currentPassword').value;
    const newPwd  = document.getElementById('newPassword').value;
    const confirm = document.getElementById('confirmNewPassword').value;
    if (newPwd !== confirm) { showNotification('Passwords do not match!', 'error'); return; }
    if (newPwd.length < 6)  { showNotification('Password must be 6+ characters!', 'error'); return; }
    try {
        await AuthAPI.changePassword(current, newPwd);
        document.getElementById('currentPassword').value = '';
        document.getElementById('newPassword').value     = '';
        document.getElementById('confirmNewPassword').value = '';
        showNotification('Password changed successfully!', 'success');
    } catch (err) {
        showNotification(err.message, 'error');
    }
}

async function deleteAccount() {
    const confirm1 = prompt('⚠️ Type "DELETE" to permanently delete your account:');
    if (confirm1 !== 'DELETE') { if (confirm1) showNotification('Cancelled.', 'info'); return; }
    if (!confirm('Final warning: All data will be permanently deleted. Continue?')) return;
    try {
        await AuthAPI.deleteAccount();
        clearSession();
        showNotification('Account deleted. Goodbye!', 'success');
        setTimeout(() => window.location.href = '/', 2000);
    } catch (err) {
        showNotification(err.message, 'error');
    }
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        AuthAPI.logout();
    }
}
