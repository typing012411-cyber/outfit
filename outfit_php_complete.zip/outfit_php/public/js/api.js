// api.js - Centralized API helper used by all pages

const API_BASE = '/api';

// ─── Token Helpers ────────────────────────────────────────────
function getToken() {
    return localStorage.getItem('outfit_token');
}

function setToken(token) {
    localStorage.setItem('outfit_token', token);
}

function setUser(user) {
    localStorage.setItem('outfit_user', JSON.stringify(user));
}

function getUser() {
    const u = localStorage.getItem('outfit_user');
    return u ? JSON.parse(u) : null;
}

function clearSession() {
    localStorage.removeItem('outfit_token');
    localStorage.removeItem('outfit_user');
}

function isLoggedIn() {
    return !!getToken() && !!getUser();
}

// ─── Core Fetch Wrapper ───────────────────────────────────────
async function apiFetch(endpoint, options = {}) {
    const headers = { 'Content-Type': 'application/json' };
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const res = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers: { ...headers, ...options.headers }
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Something went wrong');
    return data;
}

// ─── Auth APIs ────────────────────────────────────────────────
const AuthAPI = {
    async register(formData) {
        return await apiFetch('/auth/register', {
            method: 'POST',
            body: JSON.stringify(formData)
        });
    },

    async login(loginId, password) {
        const data = await apiFetch('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ loginId, password })
        });
        setToken(data.token);
        setUser(data.user);
        return data;
    },

    async forgotPassword(identifier) {
        return await apiFetch('/auth/forgot-password', {
            method: 'POST',
            body: JSON.stringify({ identifier })
        });
    },

    async resetPassword(token, newPassword) {
        return await apiFetch('/auth/reset-password', {
            method: 'POST',
            body: JSON.stringify({ token, newPassword })
        });
    },

    async getProfile() {
        return await apiFetch('/auth/profile');
    },

    async updateProfile(data) {
        return await apiFetch('/auth/profile', {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },

    async changePassword(currentPassword, newPassword) {
        return await apiFetch('/auth/change-password', {
            method: 'PUT',
            body: JSON.stringify({ currentPassword, newPassword })
        });
    },

    async deleteAccount() {
        return await apiFetch('/auth/account', { method: 'DELETE' });
    },

    logout() {
        clearSession();
        window.location.href = '/login.php';
    }
};

// ─── Wardrobe APIs ────────────────────────────────────────────
const WardrobeAPI = {
    async getWardrobe() {
        return await apiFetch('/wardrobe');
    },

    async addItem(category, name, color, imageFile) {
        const formData = new FormData();
        formData.append('name', name);
        formData.append('color', color);
        formData.append('image', imageFile);

        const token = getToken();
        const res = await fetch(`${API_BASE}/wardrobe/add/${category}`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to add item');
        return data;
    },

    async deleteItem(category, itemId) {
        return await apiFetch(`/wardrobe/item/${category}/${itemId}`, {
            method: 'DELETE'
        });
    },

    async trackOutfit() {
        return await apiFetch('/wardrobe/track-outfit', { method: 'POST' });
    }
};

// ─── Auth Guard ───────────────────────────────────────────────
function requireAuth() {
    if (!isLoggedIn()) {
        window.location.href = '/login.php';
        return false;
    }
    return true;
}

function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        window.location.href = '/dashboard.php';
    }
}

// ─── Alert Helper ─────────────────────────────────────────────
function showAlert(elementId, message, type) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.className = `alert alert-${type}`;
    el.textContent = message;
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 5000);
}

// ─── Notification ─────────────────────────────────────────────
function showNotification(message, type = 'info') {
    const existing = document.getElementById('globalNotification');
    if (existing) existing.remove();

    const n = document.createElement('div');
    n.id = 'globalNotification';
    n.textContent = message;
    n.style.cssText = `
        position: fixed; top: 20px; right: 20px;
        background: ${type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : '#3B82F6'};
        color: white; padding: 15px 25px; border-radius: 10px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2); z-index: 10000;
        font-family: 'Segoe UI', sans-serif; font-size: 1rem;
        animation: slideInRight 0.3s ease-out;
    `;

    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from { transform: translateX(400px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    document.body.appendChild(n);

    setTimeout(() => { n.remove(); }, 3500);
}
