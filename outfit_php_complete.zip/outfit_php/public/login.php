<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Outfit Helper</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/auth.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <a href="/index.php" class="back-link">← Back to Home</a>
                <h1>Welcome Back!</h1>
                <p>Login to access your wardrobe</p>
            </div>
            <div id="loginAlert" class="alert" style="display:none;"></div>
            <form id="loginForm" class="auth-form">
                <div class="form-group">
                    <label for="loginId">Login ID or Email</label>
                    <input type="text" id="loginId" required placeholder="Enter your login ID or email">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="password" required placeholder="Enter your password">
                        <span class="password-toggle" onclick="togglePassword('password')">👁️</span>
                    </div>
                </div>
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" id="rememberMe">
                        <span>Remember me</span>
                    </label>
                    <a href="/forgot-password.php" class="link">Forgot Password?</a>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
            <div class="auth-footer">
                <p>Don't have an account? <a href="/register.php" class="link">Sign Up Free</a></p>
            </div>
        </div>
    </div>
    <script src="/js/api.js"></script>
    <script src="/js/auth.js"></script>
</body>
</html>
