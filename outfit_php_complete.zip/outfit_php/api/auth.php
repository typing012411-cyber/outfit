<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/../includes/helpers.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

if (preg_match('#/api/auth/register#', $path) && $method === 'POST') { handleRegister(); }
elseif (preg_match('#/api/auth/login#', $path) && $method === 'POST') { handleLogin(); }
elseif (preg_match('#/api/auth/forgot-password#', $path) && $method === 'POST') { handleForgotPassword(); }
elseif (preg_match('#/api/auth/reset-password#', $path) && $method === 'POST') { handleResetPassword(); }
elseif (preg_match('#/api/auth/profile#', $path) && $method === 'GET') { handleGetProfile(); }
elseif (preg_match('#/api/auth/profile#', $path) && $method === 'PUT') { handleUpdateProfile(); }
elseif (preg_match('#/api/auth/change-password#', $path) && $method === 'PUT') { handleChangePassword(); }
elseif (preg_match('#/api/auth/account#', $path) && $method === 'DELETE') { handleDeleteAccount(); }
else { jsonError('Not found', 404); }

function handleRegister() {
    $body = getBody();
    $name=$trim=$body['name']??''; $name=trim($name);
    $gender=trim($body['gender']??'');
    $email=strtolower(trim($body['email']??''));
    $mobile=trim($body['mobile']??'');
    $loginId=trim($body['loginId']??'');
    $password=$body['password']??'';
    if(!$name||!$gender||!$email||!$mobile||!$loginId||!$password) jsonError('All fields are required');
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)) jsonError('Invalid email address');
    if(strlen($loginId)<4) jsonError('Login ID must be at least 4 characters');
    if(strlen($password)<6) jsonError('Password must be at least 6 characters');
    if(!in_array($gender,['male','female','other','prefer-not-to-say'])) jsonError('Invalid gender');
    $db=getDB();
    $s=$db->prepare('SELECT id,email,login_id FROM users WHERE email=? OR login_id=?');
    $s->execute([$email,$loginId]);
    $ex=$s->fetch();
    if($ex){ if($ex['email']===$email) jsonError('Email already registered'); jsonError('Login ID already taken'); }
    $db->prepare('INSERT INTO users (name,gender,email,mobile,login_id,password) VALUES (?,?,?,?,?,?)')->execute([$name,$gender,$email,$mobile,$loginId,hashPassword($password)]);
    jsonResponse(['message'=>'Registration successful! Please login.'],201);
}

function handleLogin() {
    $body=getBody(); $loginId=trim($body['loginId']??''); $password=$body['password']??'';
    if(!$loginId||!$password) jsonError('Login ID and password are required');
    $db=getDB(); $s=$db->prepare('SELECT * FROM users WHERE login_id=? OR email=?'); $s->execute([$loginId,$loginId]); $user=$s->fetch();
    if(!$user||!verifyPassword($password,$user['password'])) jsonError('Invalid credentials',401);
    $token=jwtEncode(['userId'=>$user['id']]);
    jsonResponse(['message'=>'Login successful','token'=>$token,'user'=>['id'=>$user['id'],'name'=>$user['name'],'gender'=>$user['gender'],'email'=>$user['email'],'mobile'=>$user['mobile'],'loginId'=>$user['login_id'],'outfitsCreated'=>(int)$user['outfits_created'],'createdAt'=>$user['created_at']]]);
}

function handleForgotPassword() {
    $body=getBody(); $identifier=trim($body['identifier']??'');
    if(!$identifier) jsonError('Email or Login ID is required');
    $db=getDB(); $s=$db->prepare('SELECT * FROM users WHERE email=? OR login_id=?'); $s->execute([$identifier,$identifier]); $user=$s->fetch();
    if(!$user) jsonError('No account found with this email or login ID',404);
    $rawToken=bin2hex(random_bytes(32)); $hashedToken=hash('sha256',$rawToken);
    $expires=date('Y-m-d H:i:s',time()+1800);
    $db->prepare('UPDATE users SET reset_token=?,reset_token_expires=? WHERE id=?')->execute([$hashedToken,$expires,$user['id']]);
    $resetUrl=SITE_URL."/reset-password.php?token=$rawToken";
    $html="<div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'><div style='background:linear-gradient(135deg,#9333EA,#EC4899);padding:30px;text-align:center;border-radius:10px 10px 0 0;'><h1 style='color:white;margin:0;'>&#128084; Outfit Helper</h1></div><div style='background:#f9f9f9;padding:30px;border-radius:0 0 10px 10px;'><h2>Password Reset Request</h2><p>Hi {$user['name']},</p><p>You requested to reset your password. Click the button below to reset it.</p><a href='$resetUrl' style='display:inline-block;background:#9333EA;color:white;padding:15px 30px;border-radius:8px;text-decoration:none;font-weight:bold;margin:20px 0;'>Reset My Password</a><p style='color:#666;font-size:0.9rem;'>This link expires in 30 minutes.</p></div></div>";
    $headers="MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\nFrom: ".MAIL_FROM_NAME." <".MAIL_FROM.">\r\n";
    @mail($user['email'],'Password Reset Request - Outfit Helper',$html,$headers);
    jsonResponse(['message'=>"Password reset link sent to {$user['email']}"]);
}

function handleResetPassword() {
    $body=getBody(); $token=$body['token']??''; $newPassword=$body['newPassword']??'';
    if(!$token||!$newPassword) jsonError('Token and new password are required');
    if(strlen($newPassword)<6) jsonError('Password must be at least 6 characters');
    $hashedToken=hash('sha256',$token);
    $db=getDB(); $s=$db->prepare('SELECT * FROM users WHERE reset_token=? AND reset_token_expires>NOW()'); $s->execute([$hashedToken]); $user=$s->fetch();
    if(!$user) jsonError('Invalid or expired reset token',400);
    $db->prepare('UPDATE users SET password=?,reset_token=NULL,reset_token_expires=NULL WHERE id=?')->execute([hashPassword($newPassword),$user['id']]);
    jsonResponse(['message'=>'Password reset successful! Please login.']);
}

function handleGetProfile() {
    $userId=requireAuth(); $db=getDB();
    $s=$db->prepare('SELECT id,name,gender,email,mobile,login_id,outfits_created,created_at FROM users WHERE id=?'); $s->execute([$userId]); $user=$s->fetch();
    if(!$user) jsonError('User not found',404);
    jsonResponse(['id'=>$user['id'],'name'=>$user['name'],'gender'=>$user['gender'],'email'=>$user['email'],'mobile'=>$user['mobile'],'loginId'=>$user['login_id'],'outfitsCreated'=>(int)$user['outfits_created'],'createdAt'=>$user['created_at']]);
}

function handleUpdateProfile() {
    $userId=requireAuth(); $body=getBody();
    $name=trim($body['name']??''); $gender=trim($body['gender']??''); $email=strtolower(trim($body['email']??'')); $mobile=trim($body['mobile']??'');
    if(!$name||!$gender||!$email||!$mobile) jsonError('All fields are required');
    $db=getDB(); $s=$db->prepare('SELECT id FROM users WHERE email=? AND id!=?'); $s->execute([$email,$userId]);
    if($s->fetch()) jsonError('Email already in use');
    $db->prepare('UPDATE users SET name=?,gender=?,email=?,mobile=? WHERE id=?')->execute([$name,$gender,$email,$mobile,$userId]);
    $s=$db->prepare('SELECT id,name,gender,email,mobile,login_id,outfits_created,created_at FROM users WHERE id=?'); $s->execute([$userId]); $user=$s->fetch();
    jsonResponse(['message'=>'Profile updated','user'=>['id'=>$user['id'],'name'=>$user['name'],'gender'=>$user['gender'],'email'=>$user['email'],'mobile'=>$user['mobile'],'loginId'=>$user['login_id'],'outfitsCreated'=>(int)$user['outfits_created'],'createdAt'=>$user['created_at']]]);
}

function handleChangePassword() {
    $userId=requireAuth(); $body=getBody(); $current=$body['currentPassword']??''; $newPassword=$body['newPassword']??'';
    if(!$current||!$newPassword) jsonError('Both passwords required');
    if(strlen($newPassword)<6) jsonError('New password must be at least 6 characters');
    $db=getDB(); $s=$db->prepare('SELECT password FROM users WHERE id=?'); $s->execute([$userId]); $user=$s->fetch();
    if(!verifyPassword($current,$user['password'])) jsonError('Current password is incorrect',400);
    $db->prepare('UPDATE users SET password=? WHERE id=?')->execute([hashPassword($newPassword),$userId]);
    jsonResponse(['message'=>'Password changed successfully']);
}

function handleDeleteAccount() {
    $userId=requireAuth(); $db=getDB();
    $s=$db->prepare('SELECT image_url FROM wardrobe_items WHERE user_id=?'); $s->execute([$userId]);
    foreach($s->fetchAll() as $item){ $p=__DIR__.'/../public'.$item['image_url']; if(file_exists($p)) @unlink($p); }
    $db->prepare('DELETE FROM users WHERE id=?')->execute([$userId]);
    jsonResponse(['message'=>'Account deleted successfully']);
}
