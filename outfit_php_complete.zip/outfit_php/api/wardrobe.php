<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/../includes/helpers.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

$VALID_CATEGORIES = ['shirts','tshirts','pants','shoes','dresses'];

if (preg_match('#/api/wardrobe/add/(\w+)#', $path, $m) && $method === 'POST') {
    handleAddItem($m[1], $VALID_CATEGORIES);
} elseif (preg_match('#/api/wardrobe/item/(\w+)/(\d+)#', $path, $m) && $method === 'DELETE') {
    handleDeleteItem($m[1], (int)$m[2], $VALID_CATEGORIES);
} elseif (preg_match('#/api/wardrobe/track-outfit#', $path) && $method === 'POST') {
    handleTrackOutfit();
} elseif (preg_match('#/api/wardrobe#', $path) && $method === 'GET') {
    handleGetWardrobe();
} else {
    jsonError('Not found', 404);
}

function handleGetWardrobe() {
    $userId = requireAuth();
    $db = getDB();
    $s = $db->prepare('SELECT id, category, name, color, image_url, created_at FROM wardrobe_items WHERE user_id = ? ORDER BY created_at DESC');
    $s->execute([$userId]);
    $items = $s->fetchAll();

    $wardrobe = ['shirts'=>[],'tshirts'=>[],'pants'=>[],'shoes'=>[],'dresses'=>[]];
    foreach ($items as $item) {
        $wardrobe[$item['category']][] = [
            '_id'      => $item['id'],
            'name'     => $item['name'],
            'color'    => $item['color'],
            'imageUrl' => $item['image_url'],
            'createdAt'=> $item['created_at']
        ];
    }
    jsonResponse($wardrobe);
}

function handleAddItem($category, $validCats) {
    $userId = requireAuth();
    if (!in_array($category, $validCats)) jsonError('Invalid category');

    if (empty($_FILES['image'])) jsonError('Image is required');
    $name  = trim($_POST['name'] ?? '');
    $color = trim($_POST['color'] ?? '');
    if (!$name || !$color) jsonError('Name and color are required');

    $file = $_FILES['image'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp'])) jsonError('Only jpg, jpeg, png, webp allowed');
    if ($file['size'] > 5 * 1024 * 1024) jsonError('File too large (max 5MB)');

    $uploadDir = __DIR__ . '/../public/uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $filename = $userId . '-' . time() . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = $uploadDir . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) jsonError('Failed to save image');

    $imageUrl = '/uploads/' . $filename;
    $db = getDB();
    $db->prepare('INSERT INTO wardrobe_items (user_id, category, name, color, image_url) VALUES (?,?,?,?,?)')->execute([$userId, $category, $name, $color, $imageUrl]);
    $newId = $db->lastInsertId();

    // Return full wardrobe
    $s = $db->prepare('SELECT id, category, name, color, image_url, created_at FROM wardrobe_items WHERE user_id = ? ORDER BY created_at DESC');
    $s->execute([$userId]);
    $items = $s->fetchAll();
    $wardrobe = ['shirts'=>[],'tshirts'=>[],'pants'=>[],'shoes'=>[],'dresses'=>[]];
    foreach ($items as $item) {
        $wardrobe[$item['category']][] = ['_id'=>$item['id'],'name'=>$item['name'],'color'=>$item['color'],'imageUrl'=>$item['image_url'],'createdAt'=>$item['created_at']];
    }

    jsonResponse(['message'=>'Item added successfully','wardrobe'=>$wardrobe], 201);
}

function handleDeleteItem($category, $itemId, $validCats) {
    $userId = requireAuth();
    if (!in_array($category, $validCats)) jsonError('Invalid category');

    $db = getDB();
    $s = $db->prepare('SELECT * FROM wardrobe_items WHERE id = ? AND user_id = ? AND category = ?');
    $s->execute([$itemId, $userId, $category]);
    $item = $s->fetch();
    if (!$item) jsonError('Item not found', 404);

    $path = __DIR__ . '/../public' . $item['image_url'];
    if (file_exists($path)) @unlink($path);

    $db->prepare('DELETE FROM wardrobe_items WHERE id = ?')->execute([$itemId]);

    // Return updated wardrobe
    $s = $db->prepare('SELECT id,category,name,color,image_url,created_at FROM wardrobe_items WHERE user_id=? ORDER BY created_at DESC');
    $s->execute([$userId]);
    $items = $s->fetchAll();
    $wardrobe = ['shirts'=>[],'tshirts'=>[],'pants'=>[],'shoes'=>[],'dresses'=>[]];
    foreach ($items as $i) {
        $wardrobe[$i['category']][] = ['_id'=>$i['id'],'name'=>$i['name'],'color'=>$i['color'],'imageUrl'=>$i['image_url'],'createdAt'=>$i['created_at']];
    }
    jsonResponse(['message'=>'Item deleted','wardrobe'=>$wardrobe]);
}

function handleTrackOutfit() {
    $userId = requireAuth();
    $db = getDB();
    $db->prepare('UPDATE users SET outfits_created = outfits_created + 1 WHERE id = ?')->execute([$userId]);
    jsonResponse(['message'=>'Tracked']);
}
