<?php
/**
 * Outfit Helper PHP Router
 * Place this in the root directory and configure your web server to route through it.
 * 
 * For Apache: .htaccess is included
 * For PHP built-in server: php -S localhost:8000 router.php
 */

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// API Routes
if (strpos($uri, '/api/auth/') === 0) {
    require __DIR__ . '/api/auth.php';
    exit;
}

if (strpos($uri, '/api/wardrobe') === 0) {
    require __DIR__ . '/api/wardrobe.php';
    exit;
}

// Static assets from public/
$publicPath = __DIR__ . '/public' . $uri;
if (file_exists($publicPath) && !is_dir($publicPath)) {
    // Serve static file
    $ext = strtolower(pathinfo($publicPath, PATHINFO_EXTENSION));
    $mimeTypes = [
        'css'  => 'text/css',
        'js'   => 'application/javascript',
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'webp' => 'image/webp',
        'gif'  => 'image/gif',
        'svg'  => 'image/svg+xml',
        'ico'  => 'image/x-icon',
    ];
    if (isset($mimeTypes[$ext])) {
        header('Content-Type: ' . $mimeTypes[$ext]);
        readfile($publicPath);
        exit;
    }
}

// PHP page routes
$pageMap = [
    '/'                => '/public/index.php',
    '/index.php'       => '/public/index.php',
    '/login.php'       => '/public/login.php',
    '/register.php'    => '/public/register.php',
    '/forgot-password.php' => '/public/forgot-password.php',
    '/reset-password.php'  => '/public/reset-password.php',
    '/dashboard.php'   => '/public/dashboard.php',
    '/login'           => '/public/login.php',
    '/register'        => '/public/register.php',
    '/dashboard'       => '/public/dashboard.php',
];

$cleanUri = rtrim($uri, '/') ?: '/';
if (isset($pageMap[$cleanUri])) {
    require __DIR__ . $pageMap[$cleanUri];
    exit;
}

// 404
http_response_code(404);
echo '<h1>404 Not Found</h1>';
